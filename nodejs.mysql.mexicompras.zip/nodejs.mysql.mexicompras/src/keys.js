module.exports = {

    database: {
        connectionLimit: 30,
        host: 'localhost',
        user: 'root',
        password: 'Nolose123$',
        database: 'mexicompras'
    }

};